package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Movie;

import junit.framework.TestCase;

public class MovieDAOImplTest extends TestCase {
	
	MovieDAOImpl impl;

	protected void setUp() throws Exception {
		impl= new MovieDAOImpl();
		
	}

	protected void tearDown() throws Exception {
		impl=null;
	}

	public void testGetMovie() {
		Movie movie= new Movie(1001,"Chak De India", "Shimit Amin", 999999);
		impl.addMovie(movie);
		Movie movie2= impl.getMovie(movie.getMovieId());
		assertEquals(movie.getMovieName(), movie2.getMovieName());
		
		impl.deleteMovie(movie.getMovieId());
		
	}

	public void testGetAllMovies() {
		
		List<Movie> allMovies= impl.getAllMovies();
		Movie movie= new Movie(1002, "3 idiots", "Rajkumar Hirani", 100000);
		impl.addMovie(movie);
		List<Movie> allMovies2= impl.getAllMovies();
		
		assertEquals(allMovies2.size(), allMovies.size()+1);
		
		impl.deleteMovie(movie.getMovieId());
		
	}

	public void testAddMovie() {
		List<Movie> allMovies= impl.getAllMovies();
		Movie movie= new Movie(1003, "Dil Chahta Hai", "Farhan Akhtar", 100900);
		impl.addMovie(movie);
		List<Movie> allMovies2= impl.getAllMovies();
		assertEquals(allMovies2.size(), allMovies.size()+1);
		impl.deleteMovie(movie.getMovieId());
	}

	public void testDeleteMovie() {
		
		Movie movie= new Movie(1004, "PK", "Rajkumar Hirani", 190900);
		impl.addMovie(movie);
		List<Movie> allMovies= impl.getAllMovies();
		impl.deleteMovie(movie.getMovieId());
		List<Movie> allMovies2= impl.getAllMovies();
		assertEquals(allMovies2.size(), allMovies.size()-1);
		impl.deleteMovie(movie.getMovieId());
	}

	public void testUpdateMovie() {
		Movie movie= new Movie(1005, "Barfi!", "Anurag Basu", 189900);
		impl.addMovie(movie);
		Movie movie2= new Movie(1005, "Barfi2", "AnuragBasu", 1900765);
		impl.updateMovie(movie2);
		
		assertNotSame(movie.getMovieName(), movie2.getMovieName());
		impl.deleteMovie(movie.getMovieId());
	}

	public void testIsMovieExists() {
		Movie movie= new Movie(1006, "Zindagi Na Milegi Dobara2", "Zoya Akhtar2", 100954);
		impl.addMovie(movie);
		
		assertEquals(true, impl.isMovieExists(movie.getMovieId()));
		impl.deleteMovie(movie.getMovieId());
		
	}
	
	public void testGetAllMovieNames() {
		impl.getAllMovieNames();
		assertEquals(true, true);
	}

}
