package com.dxc.pms.model; 


import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Doctor {
	
	@Id
	private int doctorId;
	private String doctorName;
	private int fees;
	
	@Embedded
	private Hospital hospital;
	
	public Doctor() {
		// TODO Auto-generated constructor stub
	}

	public Doctor(int doctorId, String doctorName, int fees, Hospital hospital) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.fees = fees;
		this.hospital = hospital;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public Hospital getHospital() {
		return hospital;
	}

	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName + ", fees=" + fees + ", hospital="
				+ hospital + "]";
	}
	
}