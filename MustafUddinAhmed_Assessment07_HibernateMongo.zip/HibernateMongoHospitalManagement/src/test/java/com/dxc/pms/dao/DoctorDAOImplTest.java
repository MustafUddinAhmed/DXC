package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Doctor;
import com.dxc.pms.model.Hospital;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	
	DoctorDAO doctorDAO;

	protected void setUp() throws Exception {
		doctorDAO= new DoctorDAOImpl();
	}

	protected void tearDown() throws Exception {
		doctorDAO=null;
	}

	public void testGetDoctor() {
		Hospital hospital1= new Hospital("AbC", "Bangalore");
		Doctor doctor1= new Doctor(1002, "Kaushik", 1001, hospital1);
		
		doctorDAO.addDoctor(doctor1);
		Doctor doctor2= doctorDAO.getDoctor(doctor1.getDoctorId());
		assertEquals(doctor1.getDoctorName(),doctor2.getDoctorName());
		doctorDAO.deleteDoctor(doctor1.getDoctorId());
	}

	public void testGetAllDoctors() {
		Hospital hospital= new Hospital("E-city Hospital","Bangalore");
		Doctor doctor= new Doctor(1002, "Mohit", 100, hospital);
		List<Doctor> allDoctors1= doctorDAO.getAllDoctors();
		doctorDAO.addDoctor(doctor);
		List<Doctor> allDoctors2= doctorDAO.getAllDoctors();
		assertEquals(allDoctors2.size(),allDoctors1.size()+1);
		doctorDAO.deleteDoctor(doctor.getDoctorId());
	}

	public void testAddDoctor() {
		Hospital hospital= new Hospital("DXC Hospital", "Chennai");
		Doctor doctor= new Doctor(1003, "Tejash", 1900, hospital);
		
		List<Doctor> allDoctors1= doctorDAO.getAllDoctors();
		doctorDAO.addDoctor(doctor);
		List<Doctor> allDoctors2= doctorDAO.getAllDoctors();
		assertNotSame(allDoctors2.size(), allDoctors1.size());
		doctorDAO.deleteDoctor(doctor.getDoctorId());
	}

	public void testDeleteDoctor() {
		
		Hospital hospital= new Hospital("ABC", "Jorhat");
		Doctor doctor1= new Doctor(1004, "Divakar", 1008, hospital);
		doctorDAO.addDoctor(doctor1);
		List<Doctor> allDoctors1= doctorDAO.getAllDoctors();
		doctorDAO.deleteDoctor(1004);
		List<Doctor> allDoctors2= doctorDAO.getAllDoctors();
		assertEquals(allDoctors2.size(),allDoctors1.size()-1);
	}

	public void testUpdateDoctor() {
		
		Hospital hospital= new Hospital("XYZ","Assam");
		Doctor doctor1= new Doctor(1007, "Abhilash", 100, hospital);
		doctorDAO.addDoctor(doctor1);
		Doctor doctor2= new Doctor(1008, "AbhilashNew", 100, hospital);
		doctorDAO.updateDoctor(doctor2);
		assertNotSame(doctor1.getDoctorName(), doctor2.getDoctorName());
		doctorDAO.deleteDoctor(doctor1.getDoctorId());
	}

	public void testIsDoctorExists() {
		Hospital hospital= new Hospital("XYZ","Assam");
		Doctor doctor1= new Doctor(1009, "Abhilash", 100, hospital);
		doctorDAO.addDoctor(doctor1);
		assertEquals(true, doctorDAO.isDoctorExists(doctor1.getDoctorId()));
		doctorDAO.deleteDoctor(doctor1.getDoctorId());
	}

}
