package com.dxc.pms.dao;

import java.util.List;

import com.dxc.pms.model.Doctor;
import com.dxc.pms.model.Hospital;

import junit.framework.TestCase;

public class DoctorDAOImplTest2 extends TestCase {

	DoctorDAO doctorDAO;
	protected void setUp() throws Exception {
		doctorDAO= new DoctorDAOImpl();
	}

	protected void tearDown() throws Exception {
		doctorDAO= null;
	}

	public void testGetDoctorsByName() {
		Hospital hospital = new Hospital("ABC", "Delhi");
		Doctor doctor = new Doctor(22, "Mustaf", 12, hospital);
		Doctor doctor2 = new Doctor(23, "Mustaf", 12, hospital);
		doctorDAO.addDoctor(doctor);
		doctorDAO.addDoctor(doctor2);
		List<Doctor> allDoctors = doctorDAO.getDoctorsByName("Mustaf");

		assertEquals(2, allDoctors.size());
		doctorDAO.deleteDoctor(doctor.getDoctorId());
		doctorDAO.deleteDoctor(doctor2.getDoctorId());
	}

}
