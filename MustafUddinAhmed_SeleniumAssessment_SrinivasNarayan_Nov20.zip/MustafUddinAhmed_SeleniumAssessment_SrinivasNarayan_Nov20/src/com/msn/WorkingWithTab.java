package com.msn;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class WorkingWithTab {

	public WebDriver driver;
	public String Browser = "chrome";

	@Test
	public void testcase1() {
		SoftAssert st = new SoftAssert();

		if (Browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver = new ChromeDriver(); // OpenBrowser
		} else if (Browser.equalsIgnoreCase("mozilla")) {
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			driver = new FirefoxDriver();
		} else if (Browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		
		// open url
		driver.get("https://www.msn.com/en-in"); 
		
		// maximize browser
		driver.manage().window().maximize(); 

		// Wait Time
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		//Clicking one note
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		
		//To Switch windows
		Set<String> allids= driver.getWindowHandles();
		Iterator<String> it= allids.iterator();
		String main= it.next();
		String t1= it.next();
		
		//Switching to Tab Window
		driver.switchTo().window(t1);
		
		driver.findElement(By.xpath("//*[@id=\"i0116\"]")).sendKeys("9876543210");
		
		
		//close window
		driver.close();
		
		//Switch driver reference
		driver.switchTo().window(main);
		
		
		//click on Skype
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		
		
		//Quiting the browser
		driver.quit();
		
	}
}
