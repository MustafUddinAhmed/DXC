package com.newsLink;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class WorkingWithLinks {
	public WebDriver driver;
	public String Browser = "chrome";

	@Test
	public void testcase1() throws IOException {
		SoftAssert st = new SoftAssert();

		if (Browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver = new ChromeDriver(); // OpenBrowser
		} else if (Browser.equalsIgnoreCase("mozilla")) {
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			driver = new FirefoxDriver();
		} else if (Browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		
		
		// open url
		driver.get("https://in.yahoo.com/"); 
		
		// maximize browser
		driver.manage().window().maximize(); 

		//Wait Time
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		//Finding News link
		List<WebElement> li = driver.findElements(By.linkText("News"));
		System.out.println("Total links="+li.size());
		
		
		//Checking existence of news link
		if(li.size()!=0) {
			System.out.println("News Link Exists");
		}
		else
			System.out.println("News Link is not available");
		
	}
}
