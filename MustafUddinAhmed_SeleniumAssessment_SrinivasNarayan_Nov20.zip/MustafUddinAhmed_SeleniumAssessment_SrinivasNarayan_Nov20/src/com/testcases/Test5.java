package com.testcases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test5 {
	public WebDriver driver;
	public String Browser = "chrome";

	@Test
	public void testCase5() {
		SoftAssert st = new SoftAssert();

		if (Browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver = new ChromeDriver(); // OpenBrowser
		} else if (Browser.equalsIgnoreCase("mozilla")) {
			System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
			driver = new FirefoxDriver();
		} else if (Browser.equalsIgnoreCase("ie")) {
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		// open url
		driver.get("http://in5cg9214x2z:9000/login.do"); 
		
		// maximize browser
		driver.manage().window().maximize(); 

		//Wait time
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		//Writing username
		WebElement username = driver.findElement(By.xpath("//input[@name='username']"));
		username.sendKeys("admin");

		//Password
		driver.findElement(By.xpath("//input[@name='pwd']")).sendKeys("manager");
		
		//Clicking Login Button
		driver.findElement(By.xpath("//a[@id='loginButton']")).click();

		// click on task
		driver.findElement(By.xpath("//a[@class='content tasks']//img[@class='sizer']")).click();

		// click on project and customers
		driver.findElement(By.xpath("//a[contains(text(),'Projects & Customers')]")).click();

		//Clicking on CreateNewProject
		driver.findElement(By.xpath(
				"//body/div[@id='container']/form[@id='customersProjectsForm']/table[@class='mainContentPadding rightPadding']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/input[2]"))
				.click();
		
		//Selecting Dropdown
		WebElement sel= driver.findElement(By.xpath("//select[@name='customerId']"));
		Select s= new Select(sel);
		s.selectByVisibleText("CustomerA");
		
		
		//Project title and Description
		driver.findElement(By.xpath("//input[@name='name']")).sendKeys("ProjectB");
		driver.findElement(By.xpath("//textarea[@name='description']")).sendKeys("DescriptionB");
		
		//Radio Button
		driver.findElement(By.xpath("//input[@id='add_tasks_action']")).click();
		
		driver.findElement(By.xpath("//input[@name='createProjectSubmit']")).click();
		
		try{
			driver.findElement(By.xpath("//span[@class='successmsg']")).isDisplayed();
			
			//Logout
					driver.findElement(By.xpath(".//*[@id='logoutLink']")).click();
			}catch(Throwable t){
				st.fail("Sucess msg does not displayed...");
				//Logout
				driver.findElement(By.xpath(".//*[@id='logoutLink']")).click();
				//cancel creation
				driver.findElement(By.xpath(".//*[@id='DiscardChangesButton']")).click();
			}
	}
}
