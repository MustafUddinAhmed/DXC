import React, { Component } from "react";
import { Formik, Form, Field } from "formik";
import ReviewDataService from "../services/ReviewDataService";

class ReviewComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      status: true,
      reviewId: this.props.match.params.reviewId,
      productId: this.props.match.params.productId,
      review: "",
      reviewRating: "",
      button: "Update"
    };
    this.onSubmit = this.onSubmit.bind(this);
  }

  componentWillMount() {
    console.log(this.state.productId);
    console.log(this.state.reviewId);
    if (this.state.reviewId === undefined) {
      console.log("Hi");
      this.setState({
        status: false,
        reviewId: "",
        button: "Add"
      });
      return;
    }
    console.log(this.state.productId);
    ReviewDataService.getReview(this.state.productId, this.state.reviewId).then(
      response => {
        this.setState({
          review: response.data.review,
          reviewRating: response.data.reviewRating
        });
      }
    );
  }

  onSubmit(review) {
    if (this.state.button == "Add") {
      console.log(this.state.productId);
      ReviewDataService.addReview(review, this.state.productId)
        .then(() => this.props.history.push("/"))
        .catch(err => {
          this.setState({
            message: "Reveiw Id " + review.reveiwId + " already exists."
          });
        });
    } else {
      console.log("Hi");
      ReviewDataService.updateReview(this.state.productId, review).then(() =>
        this.props.history.push("/")
      );
    }
  }
  render() {
    let { reviewId, review, reviewRating, button } = this.state;
    return (
      <div className="container">
        <Formik
          initialValues={{ reviewId, review, reviewRating }}
          enableReinitialize={true}
          onSubmit={this.onSubmit}
        >
          <Form>
            <fieldset className="form-group">
              <label>Review Id</label>
              <Field
                className="form-control"
                type="text"
                name="reviewId"
                disabled={this.state.status}
              ></Field>
            </fieldset>
            <fieldset className="form-group">
              <label>Review</label>
              <Field className="form-control" type="text" name="review"></Field>
            </fieldset>

            <fieldset className="form-group">
              <label>Rating</label>
              <Field
                className="form-control"
                type="text"
                name="reviewRating"
              ></Field>
            </fieldset>
            <button className="btn btn-success" type="submit">
              {this.state.button}
            </button>
          </Form>
        </Formik>
      </div>
    );
  }
}

export default ReviewComponent;
