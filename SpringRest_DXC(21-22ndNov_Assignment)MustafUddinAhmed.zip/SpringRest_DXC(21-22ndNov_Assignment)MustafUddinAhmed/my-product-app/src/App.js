import React, { Component } from "react";
import ListProductComponent from "./components/ListProductComponent";
import { Switch, Route } from "react-router-dom";
import { BrowserRouter as Router } from "react-router-dom";
import "./App.css";
import ProductComponent from "./components/ProductComponent";
import SearchPageComponent from "./components/SearchPageComponent";
import SearchByNameComponent from "./components/SearchByNameComponent";
import ReviewComponent from "./components/ReviewComponent";

class App extends Component {
  render() {
    return (
      <div>
        <h1 align="center">My Product App</h1>
        <br />
        <Router>
          <Switch>
            <Route exact path="/" component={ListProductComponent}></Route>
            <Route
              exact
              path="/products"
              component={ListProductComponent}
            ></Route>
            <Route
              exact
              path="/products/:productId"
              component={ProductComponent}
            ></Route>
            <Route
              exact
              path="/productSearch/:prodName"
              component={SearchPageComponent}
            ></Route>
            <Route
              path="/productSearchByName"
              component={SearchByNameComponent}
            ></Route>
            <Route
              path="/review/:productId"
              component={ReviewComponent}
            ></Route>
            <Route
              path="/reviewUpdate/:productId/:reviewId"
              component={ReviewComponent}
            ></Route>
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;
