import React, { Component } from "react";
import ProductDataService from "../services/ProductDataService";
import ReviewDataService from "../services/ReviewDataService";

class ListProductComponent extends Component {
  constructor(props) {
    super(props);
    this.refreshProduct = this.refreshProduct.bind(this);
    this.deleteProductClicked = this.deleteProductClicked.bind(this);
    this.updateProductClicked = this.updateProductClicked.bind(this);
    // this.addProductClicked = this.addProductClicked.bind(this);
    this.state = {
      products: [],
      message: ""
    };
  }

  componentWillMount() {
    this.refreshProduct();
  }

  refreshProduct() {
    ProductDataService.getAllProducts().then(response => {
      this.setState({
        products: response.data
      });
    });
  }

  deleteProductClicked(productIdtoDelete) {
    ReviewDataService.deleteProduct(productIdtoDelete).then(response => {
      this.setState({
        message: "productId " + productIdtoDelete + " deleted successfully"
      });
      this.refreshProduct();
    });
  }

  updateProductClicked(productId) {
    this.props.history.push(`/products/${productId}`);
  }

  addProductClicked(productId) {
    this.props.history.push(`/products/${productId}`);
  }

  searchButtonClicked() {
    this.props.history.push(`/productSearchByName/`);
  }

  deleteReviewClicked(productId, reviewId) {
    console.log(productId);
    console.log(reviewId);
    ReviewDataService.deleteReview(productId, reviewId).then(response => {
      this.setState({
        message: "Review Deleted Successfully"
      });
      this.refreshProduct();
    });
  }

  updateReviewClicked(productId, reviewId) {
    console.log(productId);
    console.log(reviewId);
    this.props.history.push(`/reviewUpdate/${productId}/${reviewId}`);
  }

  addReviewClicked(productId) {
    this.props.history.push(`/review/${productId}`);
  }

  render() {
    return (
      <div>
        {this.state.message && (
          <div className="alert alert-success">{this.state.message}</div>
        )}
        <div className="container" align="center">
          <h3>All Products</h3>
          <div className="container">
            <table className="table table-striped table-hover">
              <thead>
                <tr>
                  <th>Product Id</th>
                  <th>Product Name</th>
                  <th>Quantity On Hand</th>
                  <th>Price</th>
                  <th>All Reviews</th>
                  <th>Update</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {this.state.products.map(product => (
                  <tr key={product.productId}>
                    <td>{product.productId}</td>
                    <td>{product.productName}</td>
                    <td>{product.quantityOnHand}</td>
                    <td>{product.price}</td>
                    <td>
                      {product.reviews.map(review => (
                        <tr>
                          <td>{review.reviewId}</td>
                          <td>{review.review}</td>
                          <td>{review.reviewRating}</td>
                          <td>
                            <button
                              className="btn btn-outline-secondary btn-sm"
                              onClick={() =>
                                this.deleteReviewClicked(
                                  product.productId,
                                  review.reviewId
                                )
                              }
                            >
                              Delete
                            </button>
                          </td>
                          <td>
                            <button
                              className="btn btn-outline-success btn-sm"
                              onClick={() =>
                                this.updateReviewClicked(
                                  product.productId,
                                  review.reviewId
                                )
                              }
                            >
                              Update
                            </button>
                          </td>
                        </tr>
                      ))}
                      <tr>
                        <button
                          className="btn btn-outline-info btn-sm"
                          onClick={() =>
                            this.addReviewClicked(product.productId)
                          }
                        >
                          Add
                        </button>
                      </tr>
                    </td>
                    <td>
                      <button
                        className="btn btn-outline-success"
                        onClick={() =>
                          this.updateProductClicked(product.productId)
                        }
                      >
                        Update
                      </button>
                    </td>
                    <td>
                      <button
                        className="btn btn-outline-danger"
                        onClick={() =>
                          this.deleteProductClicked(product.productId)
                        }
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <button
              className="btn btn btn-outline-primary"
              onClick={() => this.addProductClicked(-1)}
            >
              Add Product
            </button>
            <button
              type="button"
              className="btn btn-outline-primary"
              onClick={() => this.searchButtonClicked()}
            >
              Search Product
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default ListProductComponent;
