package com.dxc.pms.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.mongodb.WriteResult;

@Repository
public class ReviewDAOImpl implements ReviewDAO {

	@Autowired
	ProductDAO productDAO;
	@Autowired
	MongoTemplate mongoTemplate;

	Product product = new Product();
	Review review = new Review();

	@Override
	public List<Review> getAllReview(int productId) {
		System.out.println("Hi");

		product = productDAO.getProduct(productId);

		System.out.println("Bye");

		List<Review> allReview = product.getReviews();
		System.out.println(allReview);

		// return mongoTemplate.findAll(Review.class);
		return allReview;

	}

	@Override
	public boolean addReview(int productId, Review review) {

		product = productDAO.getProduct(productId);

		List<Review> allReview = product.getReviews();

		System.out.println(allReview);
		allReview.add(review);

		System.out.println(allReview);
		product.setReviews(allReview);

		System.out.println("Inside DAO :" + review);
		System.out.println("Inside DAO :" + product);

		mongoTemplate.save(product, "product");
		return true;
	}

	@Override
	public boolean deleteReview(int productId, int reviewId) {

		product = productDAO.getProduct(productId);

		List<Review> allReview = product.getReviews();

		System.out.println(allReview);

		for (Review review : allReview) {
			if (review.getReviewId() == reviewId) {
				System.out.println(review);

				allReview.remove(review);
				
				System.out.println(allReview);

				product.setReviews(allReview);
				
				System.out.println(product);

				mongoTemplate.save(product, "product");
				
				return true;

			}

		}
		return true;
	}

	@Override
	public Review getReview(int productId, int reviewId) {

		product = productDAO.getProduct(productId);

		List<Review> allReview = product.getReviews();

		for (Review review : allReview) {
			if (review.getReviewId() == reviewId) {
				System.out.println(review);
			}
		}

		return review;
	}

	@Override
	public boolean updateReview(int productId, Review review) {
		
		product = productDAO.getProduct(productId);

		List<Review> allReviews = product.getReviews();

		for (Review x : allReviews) {
			if (x.getReviewId() == review.getReviewId()) {
				
				System.out.println(x);
				
				allReviews.remove(x);
				
				allReviews.add(review);
				
				product.setReviews(allReviews);

				mongoTemplate.save(product, "product");
				
				return true;
			}
		}

		return true;
	}

}
