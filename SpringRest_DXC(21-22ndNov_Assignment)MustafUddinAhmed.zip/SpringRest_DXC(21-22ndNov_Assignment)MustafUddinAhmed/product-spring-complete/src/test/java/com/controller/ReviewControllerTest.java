package com.controller;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.dxc.pms.dao.ProductDAO;
import com.dxc.pms.dao.ProductDAOImpl;
import com.dxc.pms.dao.ReviewDAO;
import com.dxc.pms.dao.ReviewDAOImpl;
import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;

public class ReviewControllerTest {

	@Autowired
	ReviewDAO reviewImpl;
	@Autowired
	Product product;
	
	@Autowired
	ProductDAO productImpl;
	
	  @Before
	   public void setUp() {
		  
			productImpl= new ProductDAOImpl();
	   }
		
	
	
	@Test
	public void testGetAllReview() {
		
//		Review review1= new Review(98, "Good", "4");
//		Review review2= new Review(97, "Kaushik", "3");
//		
//		List<Review> reviews= new ArrayList<Review>();
//		
//		reviews.add(review1);
//		reviews.add(review2);
//		
//		System.out.println(reviews.size());
//		
//		product= new Product(9999, "Tejas", 100, 1877,reviews);
//		
//		
//		System.out.println(product);
//		
//		
//		System.out.println(product.getProductId());
//		
//		
//		int length1=reviewImpl.getAllReview(9999).size();
//		
//		System.out.println(length1);
////		
//////		System.out.println(length1);
////		System.out.println("Hi2");
////		
////		Review review3= new Review(96, "Divakar", "5");
////		reviewImpl.addReview(product.getProductId(), review3);
////		
////		int lenth2= reviewImpl.getAllReview(product.getProductId()).size();
//		
//		assertEquals(1, 1);
//		
//		reviewImpl.deleteReview(product.getProductId(), review1.getReviewId());
//		reviewImpl.deleteReview(product.getProductId(), review2.getReviewId());
////		reviewImpl.deleteReview(product.getProductId(), review3.getReviewId());
		
		
		fail("Not yet implemented");
	}

	@Test
	public void testSaveReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateReview() {
		fail("Not yet implemented");
	}

}
