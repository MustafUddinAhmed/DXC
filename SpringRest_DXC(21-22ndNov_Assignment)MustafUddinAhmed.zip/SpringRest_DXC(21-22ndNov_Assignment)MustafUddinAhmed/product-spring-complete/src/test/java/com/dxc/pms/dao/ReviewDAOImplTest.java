package com.dxc.pms.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.dxc.pms.model.Product;
import com.dxc.pms.model.Review;
import com.dxc.pms.service.ProductService;
import com.dxc.pms.service.ProductServiceImpl;
import com.dxc.pms.service.ReviewService;
import com.dxc.pms.service.ReviewServiceImpl;

public class ReviewDAOImplTest {
	
	@Autowired
	ReviewService reviewImpl;
	@Autowired
	ProductService productImpl;
	
	@Autowired
	MongoTemplate mongoTemplate;

	Product product;

	@Before
	public void setUp() throws Exception {
		
		reviewImpl=new ReviewServiceImpl();
		productImpl= new ProductServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		
		reviewImpl= null;
		productImpl= null;
	}

	@Test
	public void testGetAllReview() {
		Review review1= new Review(1, "Good", "4");
		Review review2= new Review(2, "Bad", "1");
		
		List<Review> allReviews= new ArrayList<Review>();
		allReviews.add(review1);
		allReviews.add(review2);
		System.out.println(allReviews);
		product = new Product(5001, "Chair", 100, 1800, allReviews);
		System.out.println(product);
		
		int l1= reviewImpl.getAllReview(product.getProductId()).size();
		
		System.out.println(l1);
		
		Review review3= new Review(3, "Horrible", "1");
		reviewImpl.addReview(product.getProductId(), review3);
		System.out.println(product);
		
		int l2= reviewImpl.getAllReview(product.getProductId()).size();
		
		assertEquals(l1, l2-1);
		
		
	}

	@Test
	public void testAddReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetReview() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateReview() {
		fail("Not yet implemented");
	}

}
