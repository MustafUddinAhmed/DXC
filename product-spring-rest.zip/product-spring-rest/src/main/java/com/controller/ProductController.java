package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.dao.ProductDAO;
import com.model.Product;
import com.service.ProductService;

@RestController
@RequestMapping("product")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping
	public List<Product> getAllProducts(){
		System.out.println("Fetching all products called");
		return productService.getAllProducts();
	}
	
	@GetMapping("/{productId}")
	public Product getProduct1(@PathVariable("productId")int productId) {
		System.out.println("Get Product1 called "+productId);
		return productService.getProduct(productId);
	}
	
	@DeleteMapping("/{productId}")
	public boolean deleteProduct(@PathVariable("productId")int productId) {
		System.out.println("delete product called" + productId);
		return productService.deleteProduct(productId);
	}
	

	@PostMapping()
	public boolean saveProduct(@RequestBody Product product ) {
		System.out.println("Saving a Product");
		return productService.addProduct(product);
	}

	@PutMapping()
	public boolean updateProduct(@RequestBody Product product ) {
		System.out.println("Updating a Product");
		System.out.println(product);
		return productService.updateProduct(product);
	}
}